﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingEntityLib; // For entities in OnlineShoppingEntityLib
using OnlineShoppingDataAccessLayerLib;//For online shopping data access library
using OnlineShoppingExceptionLib; //For user defined exception library

namespace OnlineShoppingBusinessLayerLib 
{
    /// <summary>
    /// This class extends the methods defined in onlineshopping business layer interface
    /// </summary>
    public class OlShoppingBusinessLayer : IBusinessLayer
    {
        /// <summary>
        /// This method will display/retrieve all the categories in the home page 
        /// </summary>
        /// <returns>List of categories from database</returns>
        public List<Home> GetAllCategoriesList()
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //retrieves all the list of categories and stored in a variable
                var clst = dal.GetAllCategoriesList();
                //returns list of categories
                return clst;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method will retrieve the products present in category when clicked on categoryname
        /// </summary>
        /// <param name="categoryName">Names of categories are passed</param>
        /// <returns>It returns the products list present in selected category</returns>
        public List<Products> GetProductsByCategory(string categoryName)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //retrieves products based on category and stores in a variable
                var p = dal.GetProductsByCategory(categoryName);
                //returns the list of products on category based
                return p;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method will retrieve the products based on the name of the product given by user
        /// </summary>
        /// <param name="productName">Names of products are passed</param>
        /// <returns>returns the products with the searched product</returns>
        public List<Products> GetProductsByProductName(string productName)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //gets the products based on the name of product search and stores it in a variable
                var p = dal.GetProductsByProductName(productName);
                //returns the list of products
                return p;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method retrieves the complete details of the product based on the id 
        /// </summary>
        /// <param name="productId">procuct id is passed</param>
        /// <returns>Returns single product based on id</returns>
        public ProductDetails GetDetailsOfProductByProductId(int productId)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //get details of single product based on product id 
                ProductDetails d = dal.GetDetailsOfProductByProductId(productId);
                //returns the details of product
                return d;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button
        /// and returns to the home page
        /// </summary>
        /// <param name="cartItem">cartitems list is passed</param>
        public void AddToCart(List<CartItems> cartItems)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //adds the products to cart
                dal.AddToCart(cartItems);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method displays all the details of products present in the cart when clicked 
        /// on cart item in home page
        /// </summary>
        /// <returns>returns added cart items</returns>
        public List<CartItems> GetCartDetails()
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //it will display the products present in the cart
                var cartDetails = dal.GetCartDetails();
                // returns the products in the cart
                return cartDetails;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }        

        /// <summary>
        /// This method adds the cart items to the ddatabase 
        /// </summary>
        /// <param name="cartItems"></param>
        public void PostToCart(CartItems cartItems)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //adding cart items before order placed or buy now
                dal.PostToCart(cartItems);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }        

        /// <summary>
        /// This method removes the products present in cart
        /// </summary>
        /// <param name="productId"> id of product is passed</param>
        public void DeleteItemFromCart(int productId)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //removes the product based on the product id
                dal.DeleteItemFromCart(productId);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }
        }

        /// <summary>
        /// This method will retrieve the user name that is stored in the database
        /// </summary>
        /// <param name="userName">User name is passed as parameter</param>
        /// <returns>Returns the user name</returns>
        public LoginDetails GetUserName(string userName)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //Getting user details and storing it in a variable 
                var uname = dal.GetUserName(userName);
                //return the details
                return uname;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }                      
        }

        /// <summary>
        /// This method will retrieve the password that is stored in the database
        /// </summary>
        /// <param name="password">password is passed as an parameter</param>
        /// <returns>Returns the password that is stored in the database</returns>
        public LoginDetails GetPassword(string password)
        {
            //try block incase if code throws an exception
            try
            {
                //creates an instance for online shopping data layer
                OlShoppingDataLayer dal = new OlShoppingDataLayer();
                //Gets the password and storing in a variable
                var pwd = dal.GetPassword(password);
                //return the password
                return pwd;
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //throws exception
                throw e;
            }
            //If other than OnlineShoppingException occurs,then it will be handled here
            catch (Exception e)
            {
                //throws exception
                throw e;
            }           
        }

    }
}