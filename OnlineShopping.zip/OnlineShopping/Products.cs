﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntityLib
{
    /// <summary>
    /// Products class
    /// </summary>
    public class Products
    {        
        /// <summary>
        /// Product Id
        /// </summary>
        public int Pid { get; set; }   

        /// <summary>
        /// Product Name (name of product)
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Picture (Image of the product)
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// Price (Price of product)
        /// </summary>
        public int Price { get; set; }       
    }
}
