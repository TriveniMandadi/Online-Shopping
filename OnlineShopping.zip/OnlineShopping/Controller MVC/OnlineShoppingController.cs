﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShoppingMvc.Models; //for online shopping models in mvc
using System.Net.Http;          // for httpclient
using Newtonsoft.Json;
namespace OnlineShoppingMvc.Controllers
{
    /// <summary>
    /// OnlineShoppingController class for MVC
    /// </summary>
    public class OnlineShoppingController : Controller
    {
        // GET: OnlineShopping        
        public ActionResult Index()
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                //call API for GET 
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    var result = client.GetStringAsync("OnlineShopping").Result;
                    //gets the list of categories 
                    var lstRec = JsonConvert.DeserializeObject<List<Home>>(result);
                    //returns the list of categories to "Index" view to display
                    return View(lstRec);
                }
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This will return the list of products when user clicks on the category 
        /// </summary>
        /// <param name="name">Category name will be send as parameter</param>
        /// <returns>returns the list of products under category</returns>
        [HttpGet]
        public ActionResult GetByCategory(string name)
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                //call API for GET
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    //Sends a Get Request to the Specified Uri
                    var result = client.GetStringAsync("OnlineShopping/GetProductsByCategory/" + name).Result;
                    //gets the list of products on clicking the category name
                    var c = JsonConvert.DeserializeObject<List<Products>>(result);
                    //returns the list of products to "GetByCategory" view to display
                    return View(c);
                }
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This will return the list of products based on the search done by the user 
        /// </summary>
        /// <param name="name">product name will be passed as a parameter</param>
        /// <returns>returns the list of products</returns>
        [HttpGet]
        public ActionResult SearchByProduct(string name)
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                //call API for Get
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    //Sends a Get Request to the Specified Uri
                    var result = client.GetStringAsync("OnlineShopping/GetProductsByProductName/" + name).Result;
                    //gets the list of products by searching the product name 
                    var p = JsonConvert.DeserializeObject<List<Products>>(result);
                    //returns the list of products to "SearchByProduct" view to display
                    return View(p);
                }
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }          
           
        }        

        /// <summary>
        /// This will display the product details based on id
        /// </summary>
        /// <param name="id">product id is sent as parameter</param>
        /// <returns></returns>
        public ActionResult GetByProductId(int id)
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                //call API for GET
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    //Sends a Get Request to the Specified Uri
                    var result = client.GetStringAsync("OnlineShopping/" + id).Result;
                    //gets the product details
                    var c = JsonConvert.DeserializeObject<ProductDetails>(result);
                    //returns the product details to "GetByProductId" view to display
                    return View(c);
                }
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This method will adds the products to the cart and returns to the home page
        /// </summary>
        /// <param name="cartItems">cartitems is send as a parameter</param>
        /// <returns>It returns to the home page that contains list of products</returns>
        /// 
        [HttpGet]
        public ActionResult AddToCart()
        {
            return View();
        }
        [HttpPost]        
        public ActionResult AddToCart(CartItems cartItems)
        {
            cartItems.Quantity = 1;
            //try block incase if code throws an exception            
            try
            {
                //checking the condition assuming with cart is empty
                if (Session["cart"] == null)
                {
                    //creating instance of list of cart items 
                    List<CartItems> items = new List<CartItems>();
                    //add cart items to cart list
                    items.Add(cartItems);
                    //Add the items in  cart to the session
                    Session.Add("cart", items);
                }
                //if session cart is not empty
                else
                {
                    //get the cart from the session
                    var cartList = (List<CartItems>)Session["cart"];
                    //add next cart item to cart list
                    cartList.Add(cartItems);
                    //update cart in session
                    Session.Add("cart", cartList);
                }
                //return to the index page after adding to cart
                return RedirectToAction("Index");
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This will display all the products present in the cart
        /// </summary>
        /// <returns>Returns the items present in the cart</returns>
        public ActionResult DisplayCart()
        {
            //try block incase if code throws an exception
            try
            {
                var cartList = (List<CartItems>)Session["cart"];
                Session.Add("cartLst", cartList);
                
                return View(cartList);
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
                     
        }
        
        /// <summary>
        /// This will remove the details present in the cart by id
        /// </summary>
        /// <param name="pid">Product id is passed as an parameter</param>
        /// <returns>returns the cart list after deleting</returns>
        [HttpGet]
        public ActionResult Delete(int pid)
        {
            //try block incase if code throws an exception
            try
            {
                var cartList = (List<CartItems>)Session["cart"];
                var item = cartList.Where(o => o.Pid == pid).FirstOrDefault();
                cartList.Remove(item);
                Session["cart"] = cartList;
                return RedirectToAction("DisplayCart");
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This will posts the list of cart items before placing order
        /// </summary>
        /// <returns>returns the cart items</returns>
        public ActionResult PostToCart()
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                var cartList = (List<CartItems>)Session["cart"];
                //call API for POST
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    var result = client.PostAsJsonAsync<List<CartItems>>("OnlineShopping/AddToCart/", cartList).Result;
                    //if posting to cart is success 
                    if (result.IsSuccessStatusCode == true)
                    {
                        ViewData.Add("msg", "posted");
                    }
                    //if posting to cart is failure
                    else
                    {
                        ViewData.Add("msg", "error");
                    }
                }
                //displays the cart list in "Postcart" view
                return View(cartList);
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
            
        }

        /// <summary>
        /// This will place the order when clicked on the button
        /// </summary>
        /// <returns>Returns to the view where it will display the message</returns>
        [Authorize]
        [HttpGet]
        public ActionResult PlaceOrder()
        {
            //try block incase if code throws an exception
            try
            {
                var cartList = (List<CartItems>)Session["cart"];
                //insert cartlist into database and remove from session
                cartList.Clear();
                //update the cart in the session
                Session["cart"] = cartList;
                //it returns to the "PlaceOrder" view
                return View();
            }
            //Exceptions will be handled here
            catch(Exception e)
            {
                throw e;
            }
        }

        [HttpGet]
        public ActionResult UpdateCartById(int id)
        {
            //try block incase if code throws an exception
            try
            {
                var cartItemsList = (List<CartItems>)Session["cart"];
                //the items that are matched with the id is stored in a variable 
                var cartItem = cartItemsList.Where(o => o.Pid == id).FirstOrDefault();
                //returns to the view
                return View(cartItem);
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This method will post the items to cart after updating
        /// </summary>
        /// <param name="cartItems">cartitems is sent as an parameter</param>
        /// <returns>Retuns the cartitems and redirects to the displaycart page</returns>
        [HttpPost]
        public ActionResult UpdateCartById(CartItems cartItems)
        {
            //try block incase if code throws an exception
            try
            {
                var cartItemsList = (List<CartItems>)Session["cart"];
                var cartItem = cartItemsList.Where(o => o.Pid == cartItems.Pid).FirstOrDefault();
                //updating with quantity 
                cartItem.Quantity = cartItems.Quantity;
                Session["cart"] = cartItemsList;
                //redirects to the "DisplayCart"
                return RedirectToAction("DisplayCart");
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// This method will cancel the order that are previously buyed by the user
        /// </summary>
        /// <param name="productId">Product Id is passed as an parameter</param>
        public ActionResult DeleteItemFromCart(int productId)
        {
            //try block incase if code throws an exception
            try
            {
                Uri uri = new Uri("http://localhost:56805/api/");
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    //Sends a delete Request to the Specified Uri
                    var result = client.DeleteAsync("OnlineShopping/DeleteProductFromPlacingOrder/" + productId).Result;
                    //if posting to cart is success 
                    if (result.IsSuccessStatusCode == true)
                    {
                        ViewData.Add("msg", "Deleted");
                    }
                    //if posting to cart is failure
                    else
                    {
                        ViewData.Add("msg", "error");
                    }
                }
                //displays the cart list in "Postcart" view
                return RedirectToAction("GetProductsFromCart");
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }                     
        }

        /// <summary>
        ///This method will get the products that are ordered by the user
        /// </summary>
        /// <returns>Returns the products that are orderd by the user</returns>
        public ActionResult GetProductsFromCart()
        {
            //try block incase if code throws an exception
            try
            {
                //localhost connection of API
                Uri uri = new Uri("http://localhost:56805/api/");
                //call API for get
                using (var client = new HttpClient())
                {
                    //sets the base address defines the uri path
                    client.BaseAddress = uri;
                    //Sends a Get Request to the Specified Uri
                    var result = client.GetStringAsync("OnlineShopping/GetProductsFromCart/").Result;
                    //gets the list of products that are ordered by the user
                    var lst = JsonConvert.DeserializeObject<List<CartItems>>(result);
                    //returns to the view
                    return View(lst);
                }
            }
            //Exceptions will be handled here
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
